# Source: admitted anchored patterns (ads)
# Generated: 202610251552
#COUNT=6
# SKIP: header=0 cosmetic=0 options=0 regex=0 no-host=0 wildcard-host=0 malformed=0 anchor-only=0
#VER=202610251552-c67ee3aa
#FMT=1
boomplaymusic.com	adapi*
nm-stream.nelonenmedia.fi	nelonenmedia-pmd-ads-*
op.hicloud.com	events-*
production-public.tubi.io	ads*
tccapis.com	banner.*
textra.me	ads*
