# Source: admitted anchored patterns (track)
# Generated: 202610251552
#COUNT=34
# SKIP: header=0 cosmetic=0 options=0 regex=0 no-host=0 wildcard-host=0 malformed=0 anchor-only=0
#VER=202610251552-f75c3d99
#FMT=1
1internet.tv	stat*
amazon.com	device-metrics-*
amazon.com	device-metrics-us*
boomplaymusic.com	log*
capcutapi.com	mssdk*
cdnvideo.ru	rum*
clickdimensions.com	analytics*
ettoday.net	ad*
fc2.com	analyzer*
gifshow.com	ulog*
grafana.net	faro-collector-prod-*
grammarly.io	f-log-*
hepsiburada.com	htm*
hismarttv.com	api-*
hismarttv.com	auth-*
instana.io	eum*
miui.com	tracking.*
moengage.com	api*
moengage.com	sdk-*
playdigo.live	t*
px-cdn.net	collector-*
px-client.net	collector-*
pxchk.net	collector-*
qq.com	report.*
radio-canada.ca	logstash-*
tiktok.com	mcs-*
tiktokv.com	mon-*
tiktokv.com	rtlog*
tiktokv.com	tnc*
tiktokv.us	tnc*
zcvh.net	t*
zijieapi.com	log*
zijieapi.com	mssdk*
zijieapi.com	tnc*
